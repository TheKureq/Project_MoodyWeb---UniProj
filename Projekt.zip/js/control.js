$(document).ready(function(){
    $(".button").on("click touchend",function(){
        var p = $(this).attr('value');
        $.get("http://192.168.137.230:80/", {select:p});

        // 192.168.137.230 telefon
        // 10.0.0.12:80 dltech1 local
        console.log("axis1")
    });
    $(".axis1").on("click touchend",function(){ // dodać on telephone click
        var p = $(this).attr('value');
        $.get("http://192.168.137.230:80/", {axis1:p});
        console.log("axis1")
    });
    $(".axis2").on("click touchend",function(){
        console.log("axis1")
        var p = $(this).attr('value');
        $.get("http://192.168.137.230:80/", {axis2:p});
    });
    $(".axis3").on("click touchend",function(){
        var p = $(this).attr('value');
        $.get("http://192.168.137.230:80/", {axis3:p});
    });
    $(".axis4").on("click touchend",function(){
        var p = $(this).attr('value');
        $.get("http://192.168.137.230:80/", {axis4:p});
    });
    $(".axis5").on("click touchend",function(){
        var p = $(this).attr('value');
        $.get("http://192.168.137.230:80/", {axis5:p});
    });
});