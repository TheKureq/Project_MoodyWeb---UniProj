$('.hero__slider').slick({
	arrows: false,
	infinite: true,
	slidesToShow: 1,
	slidesToScroll: 1,
	autoplay: true,
	autoplaySpeed: 3000,
  dots: true,
  // fade: true,
  // lazyLoad: 'progressive',
  pauseOnHover: false,
  pauseOnDotsHover: false,
  speed: 500,
});
