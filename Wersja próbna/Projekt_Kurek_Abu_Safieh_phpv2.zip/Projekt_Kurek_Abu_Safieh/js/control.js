$(document).ready(function(){
    $(".led").click(function(){
        var p = $(this).attr('value');
        $.get("http://10.0.0.12:80/", {value:p});
    });
});