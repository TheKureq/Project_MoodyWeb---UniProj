<?php
// //Zapamiętuje strona że sie logowaliśmy 
session_start();

if(isset ($_SESSION["login"]) && isset($_GET["logout"]))
{
    unset($_SESSION["login"]);

    header ("Location: index.php");
    exit();

}


if(isset ($_POST["button"]))
{
        $valid = true; //sprawdza czy wszystko jest OK
    

        //Sprawdza czy jest wypełnione
        if(empty($_POST["login"]))
        {
            $valid = false;
        }

        if(empty($_POST["password"]))
        {
            $valid = false;
        }
    
    $login = "admin";
    $password = "admin";

    if($valid == true)
    {
        if($login === $_POST["login"] && $password === $_POST["password"])
        {
            $_SESSION["login"] = $_POST["login"];
            header('Location: control.php');
            exit();
        }

        else
        {
            $error = "Błąd logowania błedy login lub hasło";
        }


    }
    else
    {
        $error = "Wypełnij wszystkie pola!";
    }
}   




// łączenie z bazą
    if($conn->connect_error)
    {
        die("Failed to connect" .$conn->connect_error);
    }
    else
    {
        $stmt = $conn->prepare("SELECT * FROM rejestracja WHERE login = ? ");
        $stmt -> bind_param("s", $login);
        $stmt -> execute();
        $stmt_result = $stmt->get_result();
        if($stmt_result->num_rows > 0)
        {
            $data = $stmt_result -> fetch_assoc();
            if($data['password'] === $password)
            {
                header('Location: control.php');
                exit();
            }
        }
        else
        {
            print "invalid Email or Password";
        }
    }

?>


